# Condi-Mirai
layer7 mirai private layer4 ovh bypass nfo bypass
![photo_2022-07-07_01-37-29](https://user-images.githubusercontent.com/108882455/177797081-660df1ee-4938-43b6-9fac-573e6df1ff51.jpg)


my tg: @lion001am

leaked cuz @zxcr9999 scam


@KingOfZero kid using and selling this leaked by me sources
